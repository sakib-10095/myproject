from django.shortcuts import render, redirect
from django.http import HttpResponse
from  django.contrib.auth import login,authenticate
from  django.contrib.auth.models import User


def singupPage(request):
    if request.method=='POST':
        uname=request.POST.get("username")
        email=request.POST.get("email")
        pass1=request.POST.get("password1")
        pass2=request.POST.get("password2")

       
        if pass1!=pass2:
            return HttpResponse("password not match")
        else:
            myuser=User.objects.create_user(uname,email,pass1)
            myuser.save()
            return render(request,"login.html")
        
    return render(request,'signup.html')

def loginPage(request):
    
    if request.method=='POST':
        luname=request.POST.get("username")
        lpass=request.POST.get("pass")
        user=authenticate(request,username=luname,password=lpass)

        if user != None:
             login(request,user)
             return redirect("homepage")
        else:
            return HttpResponse("invalid username")
        
    return render(request,"login.html")  
        


def homepage(request):

    return render(request,"home.html")  